# SimpleVlogEditor MCP operations

## Long-video editorial analysis

- Before cutting, follow [cut-inspection.md](cut-inspection.md): four seconds
  before/after every boundary, actual frames and source audio at 200 ms plus
  the transcript, before committing any removal or enabling detected silence.
- `get_audio_levels`: decode any explicit source `start`/`end`, no prior
  analysis required. Default `interval: 0.2` measures all PCM in each bin;
  returns RMS/peak, dBFS, per-channel levels and coverage. Ranges up to 120s.
  `includeAudio: true` attaches original WAV as native MCP audio (up to 12s,
  8 MiB) for listening; never infer speech/sound meaning from meters alone.
  Source reads can extend beyond a split's trim into its original neighbour.
  Missing coverage is unknown, not silence. No audio track is explicit `noAudio`.
  Include a unique `requestId` for operation progress/cancellation.

- `transcribe` with `includeWords: false`: caches the complete source transcript,
  returning quality and bounded analysis-block metadata without every word.
- `get_analysis_blocks`: reads sentence/pause boundary suggestions, each at most
  300 source seconds. Add `blockIndex` to read one block's words, text and silence
  ranges. Refine the boundaries with semantic/visual analysis before `split_clip`.
- `analyze_silence`: returns `scopedSilenceRanges` with original `rangeIndex`,
  per-clip statistics, `cutSilenceEnabled` and `appliedSilenceSeconds`. Detection
  does not activate cutting; commit the intended settings and verify the timeline.

## Video packaging (thumbnails and metadata)

- `prepare_packaging_background`: deterministic exposure/colour/contrast pass on
  a current saved `sourceFramePath`; writes a lossless PNG without scene/face
  reconstruction. Inspect it and use its `path` as the cover-generation background,
  while preserving the original `sourceFramePath`/`outputTime` for provenance.
  Include `preparedBackgroundPath` in thumbnail delivery; the editor verifies
  that it belongs to that original frame. Exposure, contrast and saturation can
  be adjusted within the tool's limits. No grain or sharpening is introduced.

- `set_video_packaging`: place up to three generated 16:9 image paths, three matching titles, a complete description and tags in the visible Video Packaging tool. Every thumbnail also supplies `sourceFramePath`, final-timeline `sourceTimestamp`, the active `tagStyleId` and `tagStyleReferencePath`, `letteringMethod`, and a checked `styleVerification`; stale backgrounds or style references are refused. Use it for deliverable thumbnails or video metadata instead of adding them to the timeline. Omitted fields remain unchanged and the page receives focus after insertion.
- `get_video_packaging`: inspect the currently displayed package before a partial update or to verify delivery.
- `clear_video_packaging`: remove the complete displayed package.
- `get_packaging_sources`: one read of everything a packaging run needs — whether a project is loaded, which clips already have a transcript or saved cover backgrounds, what was understood on an earlier pass, the links the QR tags carry, and where covers may be written. Requires the Video Editor page to be open.
- `save_frames`: write chosen frames to disk at full size, beside the footage, to serve as cover backgrounds. It saves the finished picture (the same composition as `get_frames` `composited: true`) and returns each file's `path`, source `timestamp` and `outputTime`. Instants that were cut out, fall inside a transition, or need a person cut-out the machine cannot compute are refused with `unfaithful_frame` and a `suggestedTimestamp`, before anything is written. Each file is tied to the edit it came from: after any later change it no longer counts as a background, and `set_video_packaging` refuses covers drawn on it.
- `get_packaging_tag_style` / `set_packaging_tag_style`: the lettering every cover has to copy. The active style returns a stable id and a written reference-image path; attach that exact image to every cover generation and retain the pair in delivery metadata. The user may choose a shipped style or load their own. When the user asked to be consulted, `get_packaging_tag_style` opens the picker on screen and waits for them.
- `set_video_understanding` / `get_video_understanding`: store and read back the summary, topics, chapters, highlights and language of the video, so a later run does not read the transcript and the frames again.

The `create-video-packaging` skill is the workflow these belong to. Run it as soon as `finish_editing` returns **only when** its result says `videoPackaging.automatic: true`; the project setting `autoVideoPackaging` (a checkbox in the Video Editor's project settings, on by default) decides. When it is `false`, package only on the user's explicit request. `set_project_settings` accepts `{ "autoVideoPackaging": true | false }` — change it only when the user asks.

Always call `get_editor_capabilities` because the running editor is the final authority. This reference explains the intended workflow and the stable operation families.

## Automatic recovery

The MCP host retries supported transient failures of lightweight reads up to three times, waiting for a dropped connection or reopening an unresponsive editor from its checkpoint. If the failure still reaches the client, inspect health and diagnostics and use at most one additional recovery attempt. Report an unresolved failure rather than looping. **Transcription
is not replayed after a restart or dropped connection**: `transcription_interrupted`
requires reading the restored project and explicitly retrying with a new requestId.
`transcription_stalled`, `transcription_stage_timeout`, decoding/recognition errors
and cancellation are reported once with their actual stage. Keep them visible;
do not blindly repeat the same model/file. Inspect `get_operation_status` and
`get_diagnostics` for the last phase, detail and percentage. The whole-operation
budget defaults to 30 minutes; no-progress budget defaults to five minutes;
explicit shorter budgets are honoured. Audio reads and worker startup also have
60-second limits. Repeated identical progress does not renew the deadline.
A change interrupted by a
restart is not replayed blindly: it comes back as `editor_restored` (recoverable) — read
the project and resend with a new `requestId` if the change is missing. `get_frames`
also falls back from the media element to decoding the file directly when the element
stalls. An older editor already running is closed (saving its checkpoint) and replaced
by the host's own version.

## When SimpleVlogEditor is not installed (setup mode)

The plugin only looks for the editor in the installer's default folders (`%ProgramFiles%\SimpleVlogEditor`, or `%LOCALAPPDATA%\Programs\SimpleVlogEditor` for a "just for me" install). When it is not there — or is older than the plugin — the MCP server still starts, with only three tools:

- `check_installation`: looks in the default folders again. When the editor is there, its MCP host is started in the same session, the client receives `notifications/tools/list_changed`, and the full tool list below becomes available. Otherwise it answers `connected: false`, the reason, and the download link.
- `health_check`: `state: "editor_not_installed"` (or `"editor_outdated"`), the folders searched, `downloadUrl: "https://simplevlogeditor.com/"` and the next step.
- `get_editor_capabilities`: an error with the same information.

Tell the user, in their language, to download the installer from https://simplevlogeditor.com/, install it keeping the default folder, and let you know; then call `check_installation`. There is no way to point the plugin at another location.

## Understanding tools

- `queue_media_import`: enqueue an explicit array of absolute file paths (not a directory) without transferring bytes; use a stable `requestId` and never reuse it for different arguments. Pending imports are bound to the active document, even when its revision advances. `project_changed` interrupts a job if the document is replaced; inspect the project before calling `resume_import`, which explicitly targets the current document and retries unfinished/recoverable files without reimporting successful ones.
- `get_import_status`: progress, revision, imported asset IDs, and per-file outcomes.
- `cancel_import` / `resume_import`: stop or continue only the unfinished portion of a job.
- `health_check` / `get_diagnostics`: connection, process, window, queue and external-tool health.
- `get_recovery_state` / `checkpoint_project`: inspect or force the complete JSON recovery checkpoint.
- `restart_editor` / `close_editor`: save state and restart or close the visible Electron process without losing the edit.
- `get_operation_status` / `cancel_operation`: priority-channel progress and cooperative cancellation, even while the edit queue is busy.
- `finish_editing`: after editorial and technical checks, run the final-only `review-youtube-policy` gate, then show the final Preview/Render choice in the visible editor. Include its `youtubePolicyReview`; committed policy removals become a detailed alert in this modal.
- `get_project`: complete serialized edit and revision.
- `list_assets`: unique sources, media metadata, availability, and clip usage.
- `get_timeline`: source/output timing, cuts, captions, tags, transitions, audio, zooms, and push-in IDs.
- `transcribe`: a clip with no audio track is answered with `noAudio: true`, an empty transcript, a `warning`, and `isTimelapse`/`timelapseReason` — a note, not an error. Otherwise: word timestamps, grouped phrase timestamps, quality guidance, and words remapped through the current edit. Use Small Quality by default; use `auto` for spoken-language detection and Turbo when quality needs review. Voice/GTCRN + Balanced is the default denoise setup. Friendly aliases such as `base`, `small`, `turbo`, `pt`, `pt-BR`, and `en` are accepted. `timeoutMs` bounds the whole call; `stageTimeoutMs` is a no-progress watchdog renewed by real stage/ratio/detail advancement.
- `analyze_silence`: detected ranges and bounded waveform metadata. Set `includeWaveform` for the first bounded page only.
- `analyze_noise`: DNSMOS/VAD-backed background diagnosis for one clip or all audible media. Returns status, levels, quality, intervals and evidence. It never enables or applies suppression.
- `suppress_noise`: explicit per-clip removal, audible preview cache and export scheduling. Use only after an explicit user request to remove noise; default to `gtcrn` + `balanced` unless evidence says otherwise.
- `get_waveform_page`: request later waveform buckets without producing an oversized MCP response.
- `get_contact_sheet`: visual sampling of one source interval; `interval: 0.2` supports the four-second pre-cut windows (about 41 frames each). Use sparse sampling for broad coverage and split longer dense requests into bounded windows; include a unique `requestId` when progress/cancellation may be needed.
- `get_frames`: exact source frames returned as MCP image content; include a unique `requestId` when progress/cancellation may be needed.
- `export`: render to an admitted local path. Give it a unique `requestId`, poll `get_operation_status` for stage/percentage, and use `cancel_operation` to remove partial output when the user stops it.

Renderer-facing work is ordered so a read never observes half of an atomic batch and browser decoders are not exhausted. Priority health, import/operation status, diagnostics, cancellation, close, and restart remain responsive. Iterate over all distinct assets. Start with contact sheets, then request exact frames at speech boundaries and uncertain moments rather than sampling hundreds of redundant images.

Project-changing calls require a non-empty `requestId`: `add_media`,
`queue_media_import`, `open_project`, `set_project_soundtrack`,
`analyze_silence`, `analyze_noise`, `suppress_noise`, committed `apply_edit_batch`, `undo`, and `redo`. Generate a
new id for a new intended mutation. If the connection drops before the result is
known, retry the exact payload with the exact same id; Electron returns the
original in-flight/completed result. A reused id with different content fails
with `idempotency_conflict`. After an Electron restart, re-read the project and
use fresh ids and the current revision.

## Timeline operations

`apply_edit_batch` accepts atomic operation groups for:

- removing, moving, and duplicating clips;
- adding and updating text cards and their image backgrounds;
- adding and updating transitions;
- splitting, trimming, clearing trims, deleting source ranges, and restoring ranges;
- enabling or disabling detected silence ranges;
- setting image duration, speed, volume, audio mode, fades, silence behavior, denoise-related edit settings, and automatic zoom settings;
- scheduling per-clip noise removal with `set_noise_suppression` (checkbox semantics only; it does not process immediately);
- attaching or detaching project or per-clip audio;
- adding, updating, and removing captions;
- adding, updating, and removing ordinary, social, Subscribe, and QR Code tags;
- adding, updating, and removing manual dynamic push-ins;
- changing aspect ratio, reframe mode, resolution, output formats, loudness, soundtrack fades, and project defaults.
  Loudness is the interface's *Even out the volume across the project*: `set_project_settings` → `{ "loudness": { "enabled": true } }`, which an autonomous vlog edit always switches on (see the `edit-vlog` skill).

Use `undo` and `redo` for whole batches. Use `preview` to open, seek, play, pause, or close the shared edited-timeline preview. Pass `clipId` with `open` or `play` to start at that selected item’s first kept frame after trims, removed ranges, speed and transitions; omit it and seek to `0` for the separate whole-project-from-start action. Use `save_project`, `open_project`, and `export` only with paths admitted by the Electron MCP bridge.

### Caption groups and Background captions

Read `get_editor_capabilities.captions.presetGroups`, `fonts`, and `animations` instead of inventing IDs. The `classic` group contains ordinary caption designs. The `background` group contains ready-made upper-left, upper-center, upper-right, center-left, center, and center-right designs that use the existing caption timeline. Its expanded presets combine clean, rounded, serif, mono, condensed, display, geometric, slab-serif, and handwritten letterforms with still, subtle zoom, or slow scroll motion. They draw the text, then place a worker-generated portrait matte over it in both preview and export. The legacy `behind-subject` ID is the still upper-center background preset. The first use may download the local ONNX model. If segmentation is unavailable or no person is found, the text remains visible and the selected background preset and motion are preserved.

```json
{
  "type": "add_caption",
  "clipId": "clip-3",
  "start": 12.4,
  "duration": 2.8,
  "text": "2 DIAS",
  "caption": {
    "stylePreset": "behind-subject-zoom-in-display",
    "positionX": 0.5,
    "positionY": 0.5,
    "animation": "zoom-in",
    "fontScale": 0.28
  }
}
```

**Minimum time on screen.** A tag and a background caption both need more than
four seconds. Below that they read as a flicker: a Subscribe badge or QR code
nobody had time to act on is worse than none, and a large title that leaves
before it can be read only competes with the shot. Give every tag, and every
caption from the `background` group, a duration above four seconds — longer when
the wording is long or the shot is busy. Ordinary `classic` subtitles are
exempt; they follow the speech and the suggested reading time already sizes them.

Use source seconds. `positionX` and `positionY` are normalized frame coordinates. Inspect representative frames before choosing placement, keep the coordinates fixed throughout the interval, and use short text so the subject hides only part of the lettering.

Music defaults to the project, not a clip. For a generic request such as “add background music,” call `set_project_soundtrack` early. This explicit project setting supplies silent clips, timelapses, images, and text cards. `attach_audio` without `clipId` remains compatible inside a batch; supply `clipId` only for an explicitly named section.

Before importing media, prefer an existing `simplevlogeditor-recovery.sve.json` or other saved `.sve.json` in the working media directory. Open it and inspect `recoveryReport`; import only missing/new sources. After every open, recovery, or restart, call `get_project` and discard all prior revisions/request ids.

Text cards should have fade-in and fade-out treatment. Fade out the preceding video and fade in the following one around the card. Use a transition for adjacent clips that continue the same topic; prefer a fade-out/fade-in break when the subject changes.

## Push-in example

```json
{
  "expectedRevision": 12,
  "requestId": "3ec75fc9-fbdd-49a7-a351-d2c48ed7c60c",
  "label": "Emphasize the conclusion",
  "dryRun": true,
  "operations": [
    {
      "type": "add_push_in",
      "clipId": "clip-3",
      "start": 42.1,
      "end": 47.4,
      "scalePercent": 16,
      "rampSeconds": 0.45,
      "easeOut": true
    }
  ]
}
```

Use `get_timeline` after committing to obtain the generated `pushInId` for updates or removal.

## Subscribe and QR example

```json
{
  "operations": [
    {
      "type": "set_tag",
      "clipId": "clip-3",
      "tag": {
        "text": "Subscribe",
        "shape": "social-subscribe",
        "position": "bottom-right",
        "startSeconds": 2
      }
    },
    {
      "type": "set_tag",
      "clipId": "clip-7",
      "tag": {
        "text": "Open the link",
        "shape": "qr-subscribe",
        "qrText": "https://example.com",
        "position": "bottom-left"
      }
    }
  ]
}
```

Use shape IDs returned by `get_editor_capabilities`; do not assume this example is exhaustive.
# Video Effects (container only)

Discover IDs in `get_editor_capabilities.videoEffects.presets`. Example operation inside a revision-guarded, idempotent `apply_edit_batch`:

```json
{ "type": "set_video_effect", "clipId": "clip-1", "effectId": "background-blur", "intensity": 0.75 }
```

Use `effectId: "none"` to restore Original. No global effect exists. `get_timeline` reports each container's saved `videoEffect`. Effects are composited before captions and tags, including both sides of transitions. Local segmentation is shared with Behind Subject captions. Missing subjects retain the original picture; unavailable GPU/models show an explicit preview warning and prevent silent effect omission during export. Depth/face/pose are not selectable presets yet.

## Video Effect sections

| Operation | Required | Optional |
| --- | --- | --- |
| `set_video_effect` | `clipId`, `effectId` | `intensity` |
| `add_video_effect` | `clipId`, `start`, `effectId` | `duration`, `intensity`, `fadeSeconds` |
| `update_video_effect` | `clipId`, `videoEffectId` | `videoEffect.{effectId,intensity,startSeconds,durationSeconds,fadeSeconds}` |
| `remove_video_effect` | `clipId`, `videoEffectId` | — |

`start`, `duration`, `startSeconds`, `durationSeconds` and `fadeSeconds` are all
in **original source seconds**. A section lasts at least 0.1s. Sections may
touch exactly but never overlap; an overlapping request fails with
`video_effect_overlap` and `details` carrying `maximumDuration`, `clipBounds`
and the `occupied` ranges. `effectId: "none"` is refused — use
`remove_video_effect`. Read `get_editor_capabilities.videoEffects.presets` for
valid ids and `get_timeline` for the `videoEffectId` of an existing section.

`fadeSeconds` 0 is a hard cut into and out of the effect; above 0 eases it in
and out over that many seconds, clamped to half the section.

```json
{
  "expectedRevision": 12,
  "label": "Grade the opening line",
  "operations": [
    { "type": "add_video_effect", "clipId": "clip-1", "start": 0, "duration": 3.5,
      "effectId": "cinematic", "intensity": 0.7, "fadeSeconds": 0.5 }
  ]
}
```

# Placed images

A picture placed over a stretch of one visual container, on that container's own
source clock. Per container, never inherited, and — unlike effect sections —
free to overlap each other: a logo in a corner and a screenshot in the middle is
a normal placement.

| Operation | Required | Optional |
| --- | --- | --- |
| `add_image` | `clipId`, `path`, `start` | `duration`, `style`, `positionX`, `positionY`, `scale`, `rotationDegrees`, `opacity`, `fadeSeconds` |
| `update_image` | `clipId`, `imageId`, `image` | `image.{path,startSeconds,durationSeconds,style,positionX,positionY,scale,rotationDegrees,opacity,fadeSeconds}` |
| `remove_image` | `clipId`, `imageId` | — |

`path` is an absolute path inside the allowed roots. The editor opens and
decodes it locally; no picture bytes leave the machine. The project stores only
enough to find the file again, exactly as it does for video and music, so a
picture that is moved away is reported as missing rather than silently dropped
from the export.

| Field | Meaning |
| --- | --- |
| `style` | `overlay` sits on top of everything. `behind-subject` joins the middle layer — in front of the scenery, behind the person — like a background caption. With no person found it stays visible. |
| `positionX`, `positionY` | The **centre** of the picture, 0–1, as shares of the finished frame. 0.5, 0.5 is the middle. |
| `scale` | Width as a share of the frame width, 0.02–2. The aspect ratio is always kept, so this is the whole size control. |
| `rotationDegrees` | −180 to 180. **Stay within ±20 unless the user asked for more.** |
| `opacity` | 0.05–1, steady, separate from the fades at the two ends. |
| `fadeSeconds` | 0–10. 0 is a hard cut; above 0 fades the picture in and out, clamped to half the placement. |

`start`, `duration`, `startSeconds` and `durationSeconds` are in **original
source seconds**. A placement lasts at least 0.2s.

Across a transition, `overlay` placements from both joined containers keep
drawing, while `behind-subject` ones stand down for the length of the join — the
same thing a Background Caption does, because two shots mean two mattes. Prefer
`overlay` for a picture that has to survive a join.

`get_timeline` returns each placement under the container's `images`, with
`imageId`, `name`, `path`, the natural pixel size, the placement values, the
measured `box` in frame pixels, `fitsInFrame`, and `covers` — the captions and
tag this picture is drawn over, measured by the editor from the same geometry it
draws with. A non-empty `covers` is a placement to fix.

The editor's panel can show the user either the original file clock or the
edited clip clock. That is a display choice in its fields and changes nothing
here: every time in every operation and every reply is original source seconds.
`get_editor_capabilities.timeSpace` says the same.

## Verifying a placement

`get_frames` returns the **source** frame by default: no zoom, no caption, no
effect, no placed picture. Pass `composited: true` to get the frame as the
export will write it, at the project's frame ratio. That is the only way to see
whether a picture lands whole and in the right place.

```json
{ "clipId": "clip-1", "timestamps": [12.4], "width": 720, "composited": true }
```

The result carries `frame` (the export's pixel size), the per-frame `outputTime`,
the container's `images` report, `allFaithful` and `subjectLayerRendered`. Each
frame also says `faithful`, and when it is not, `unfaithfulReason` (`removed`,
`transition`, `subject-unavailable`, `effect`) and a `note`: a source instant
that was cut out, or one inside a transition, is composed but is **not** a frame
the export contains. `subjectLayer` is `not-needed`, `rendered`, `no-subject`
(the model ran and found nobody — the export draws it the same way) or
`unavailable`. `subjectLayerRendered` is true only when every frame that needed
the person cut out got it: position and size are still readable when it is
false, occlusion is not. Report that rather than claiming the middle layer was
checked. `get_contact_sheet` accepts `composited: true` too.

```json
{
  "expectedRevision": 14,
  "label": "Show the chart while it is mentioned",
  "operations": [
    { "type": "add_image", "clipId": "clip-2", "path": "D:\\Videos\\chart.png",
      "start": 31.2, "duration": 5, "style": "overlay",
      "positionX": 0.72, "positionY": 0.3, "scale": 0.4,
      "rotationDegrees": 0, "fadeSeconds": 0.4 }
  ]
}
```
