---
name: edit-video
description: Use when the user wants to inspect, understand, edit, cut, rearrange, caption, style, preview, save, or export videos in SimpleVlogEditor, including removing repetitions or silence, adding text cards, placed images, Subscribe or QR tags, transitions, audio changes, and dynamic push-ins.
---

# Edit video in SimpleVlogEditor

Operate the visible Electron editor through the `simple-vlog-editor` MCP tools. Never simulate UI clicks and never rewrite editor project files with shell commands. MCP is the authoritative interface for both reading and changing the edit.

## Start every editing task

1. Call `get_editor_capabilities` to discover the exact current operations, styles, tag shapes, transitions, formats, and value limits.
2. The MCP host opens and focuses the visible Electron editor. Confirm `health_check` if it is not visible; do not continue as a hidden background-only workflow.
3. **Decide first whether you are resuming.** Call `get_recovery_state` before the first edit of a session. It reports the checkpoint's `clipCount`, `projectRevision`, the `media` it refers to with absolute paths, the `folders` those sit in, and `missingMedia`. Compare `folders` with the directory you were asked to work in: the same folder and the same files mean this is the same edit, and you continue it rather than starting again.
   - Resuming: call `open_project` on the checkpoint path, then `get_project` and `get_timeline`, and **confirm no clip is still waiting for its file before doing anything else**. The editor reconnects stored media from disk by itself, on restore and again before every command, so waiting is normally over by the time `get_project` answers. A clip still waiting means the file genuinely moved: say which one and where it was looked for, and do not transcribe, cut, preview or export that clip — those fail with `media_unavailable`, and the failure names the path it expected.
   - Not resuming, or `missingMedia` covers everything: treat it as a new project and import. Never append every source again to an already restored timeline.
   - Also look for a saved `.sve.json` in the media directory itself; the same rule applies to it.
4. For a project that really starts from source media, call `queue_media_import` with absolute paths and a request id unique to this editor session/project/revision. Poll `get_import_status` until terminal; report per-file failures and continue with imported assets. Never send or read file contents yourself.
5. Call `get_project`, `list_assets`, and `get_timeline` after every open, recovery, or restart. Discard revisions and request ids from the prior editor session; only the newly returned `projectRevision` may guard the next mutation.
6. If the user supplied general music/background audio, call `set_project_soundtrack` before editorial batches. This project-wide fallback supplies silent clips, timelapses, images, and text cards. Use per-clip audio only for an explicitly named section.
7. Take stock of the whole working directory before the first edit, and treat the three kinds of file differently:
   - **Video and music**: list them and read their names only. Their content is understood later, and only through the editor — transcripts and frame captures — never by opening the media yourself.
   - **Images**: open and actually look at every image file in the directory, with your own file tools, before planning the edit. They are small, and an image whose content you have not seen cannot be placed intelligently. Write down for each one what it shows and what it would illustrate.
   - Nothing obliges you to use an image. Decide per image whether it earns a place; say plainly which ones you left out and why. An image nobody mentions and nothing calls for is better left on disk.
8. Understand every distinct audiovisual asset before making content-based edits:
   - transcribe every asset with usable audio;
   - request a contact sheet for every asset with usable video or imagery;
   - inspect exact frames around proposed cuts, scene changes, reactions, visual actions, and ambiguous transcript moments;
   - analyze silence when pauses, speech boundaries, or cut margins matter;
   - call `analyze_noise` when background-noise evidence matters. It may inspect one clip or every audible video and never changes the audio.

For transcription, use `onnx-community/whisper-small_timestamped` by default. Use the language of the user's prompt when it is also likely to be the spoken language (`portuguese`, `english`, etc.); otherwise omit it or use `auto` so Whisper detects speech. The server accepts ISO aliases such as `pt` and friendly model aliases, but prefer canonical values returned by capabilities. If `quality.reviewRecommended` is true or the transcript is visibly incoherent, retry that clip with `onnx-community/whisper-large-v3-turbo_timestamped`. When denoise is useful, default to `noiseEngine: "gtcrn"` (Voice model) and `noiseStrength: "balanced"`.

Do not claim to have watched or understood an asset that was not covered by transcript/audio evidence and frames. If an asset cannot be decoded, report it explicitly and continue safely with the remaining material.

## Edit safely

- A request about part of a clip is a **section**: `add_video_effect` with `start` and `duration` in original source seconds, `update_video_effect` with a partial `videoEffect`, `remove_video_effect` to take one away. `set_video_effect` remains the whole-container call. Never use `effectId: "none"` to delete a section — it is refused. Sections cannot overlap; on `video_effect_overlap` read `details.maximumDuration` and `details.occupied` instead of guessing a shorter one. `fadeSeconds` is the edge: 0 is a hard cut, above 0 eases the effect in and out, clamped to half the section. Pick a fade for a smooth or subtle request and a cut for an abrupt one; default to a cut when the user did not say.
- Video Effects belong exclusively to one visual media container. Read `get_capabilities.videoEffects.presets` and use `set_video_effect` in `apply_edit_batch` with `clipId`, `effectId`, and optional `intensity` (0–1). `none` restores Original. Never invent a global effect or assume that neighboring clips inherit the selection. Inspect source frames before choosing a restrained Classic preset or a more expressive Creative preset. Creator effects use shared local subject segmentation; when no person is found the image stays original. GPU/model errors are visible in preview and stop export explicitly. Face, pose, and depth capabilities are reserved, not available effects. Re-read `get_timeline` after applying an effect and preview it before export.

- **Placed images.** `add_image` puts a picture over a stretch of one visual container: `clipId`, an absolute `path` inside the allowed roots, `start` and `duration` in original source seconds, and the placement — `style`, `positionX`, `positionY`, `scale`, `rotationDegrees`, `opacity`, `fadeSeconds`. `update_image` takes a partial `image` (send `path` inside it to swap the picture), `remove_image` takes it away. Placements are per container and never inherited; unlike effect sections they may freely overlap each other.
  - Place one **whenever the speech refers to a picture** — "this is the screenshot", "look at this chart", "here's the photo" — using the transcript timing to put it on the words. That is what this feature is for. Do not place images decoratively over speech that refers to nothing.
  - `style: "overlay"` sits on top of everything. `style: "behind-subject"` joins the middle layer, in front of the scenery and behind whoever is talking, like a background caption; with no person on screen it simply stays visible.
  - `scale` is the width as a share of the frame width and the aspect ratio is always kept, so it is the whole size control. `positionX`/`positionY` are the **centre** of the picture as shares of the frame.
  - Keep `rotationDegrees` within **±20** unless the user asked for a stronger tilt. Most placements want 0.
  - **Verify every placement you make.** Call `get_frames` with `composited: true` at a time inside the placement: that returns the frame as the export will write it, with the picture, captions and effects composited. Check with your own eyes that the whole picture is inside the frame, that it does not cover a face or the caption, and that it matches what is being said there. A plain `get_frames` call cannot answer any of this — it returns the untouched source frame. `get_timeline` also reports each placement's measured box and `fitsInFrame`; treat `fitsInFrame: false` as a placement to fix, not to explain away.
  - `get_timeline` also reports `covers` for each placement — the captions and tag the editor measured this picture as drawn over. Treat a non-empty `covers` as a placement to fix, not as a detail: the editor measured it, so "I checked the frame and it looked fine" is not an answer to it.
  - If `subjectLayerRendered` comes back false on a composited frame, the segmentation model did not run: the frame is still worth reading for position and size, but it is **not** evidence about what the person covers. Say so rather than claiming the middle layer was checked.
- Source edits, captions, placed images, and push-ins use original source seconds. Output times describe the assembled timeline. The editor's panel can show the user either clock, but that is a display choice in its fields: every time you send and every time you read back is original source seconds, whatever the user says their screen shows.
- Use `apply_edit_batch` with `expectedRevision` and `dryRun: true` before subjective or multi-operation changes. Inspect the simulated duration, then commit the same batch against the latest revision.
- A revision conflict is not retryable with the old value. Call `get_project`, rebuild the batch against that current revision, and use a new request id.
- Group related changes into meaningful batches so each group is one undo step.
- Re-read the timeline after every committed batch. Preview important joins and inspect frames around them.
- Preserve natural speech rhythm, intentional pauses, reactions, context, and important visual actions. Remove failed takes, errors, redundant repetitions, accidental long pauses, and off-topic material only when evidence supports the choice.
- Prefer restrained `add_push_in` values with smooth ramps. Use push-ins only for justified emphasis; their source timing remains aligned after cuts and speed changes.
- Add text cards, captions, transitions, Subscribe tags, QR Code tags, replacement audio, and output settings only when requested or editorially useful. Validate QR URLs and avoid covering faces or essential screen content.
- **A tag and a background caption both need more than four seconds on screen.** Anything shorter is read as a flicker rather than as a message: a Subscribe badge or a QR code nobody had time to act on is worse than none, and a large title that appears and leaves before it can be read only competes with the shot. Give every tag, and every caption from the `background` group, a duration above four seconds — longer when the wording is long or the shot is busy. Ordinary `classic` subtitles are exempt: they follow the speech, and the suggested reading time already sizes them.
- Read `get_capabilities.captions.presetGroups`, `fonts`, and `animations` before choosing a caption. Use a `classic` preset for ordinary subtitles or a `background` preset for a cinematic title that should pass behind the presenter. Background presets include still and restrained `zoom-in`, `zoom-out`, and `scroll-*` variants with different letterforms. Inspect representative frames first and choose upper-left, upper-center, upper-right, center-left, center, or center-right so enough of every word remains readable. Prefer short, strong wording and subtle motion; do not combine a moving title with a visually busy shot unless it improves clarity. The editor performs local portrait matting in a worker and keeps the saved style unchanged when it must fall back to ordinary text because no subject is found.
- Use `set_project_soundtrack` for general music and call it near the beginning so silent/timelapse clips and text cards are never previewed as unexplained silence.
- Noise suppression is always per media container. Never call `suppress_noise`, never enable `set_noise_suppression`, and never infer consent from a diagnosis unless the user explicitly asks to remove, suppress, reduce, or clean noise. A request to inspect, understand, diagnose, or report noise authorizes `analyze_noise` only. When removal is explicit, prefer Voice/GTCRN with Balanced strength unless the evidence or user specifies otherwise; `suppress_noise` creates a preview and schedules the same result for export.
- Give text cards fade-in and fade-out treatment. At their boundaries, fade out the preceding video and fade in the following video. Use ordinary transitions for clips continuing the same topic; for a clear topic change, prefer a fade-out/fade-in break. Add transitions only where content evidence justifies them.
- Never invent IDs, timing, shapes, transition names, fonts, presets, or output formats. Read them from MCP results.
- Never report success for a look that was not produced. `export` failing with `subject_vision_failed` means the Video Effect or Background Caption was not applied; report the `kind` and `surface` from its details and offer the Classic preset or Original alternative. A `no-subject` result is not a failure: the caption renders as ordinary text and the picture stays original by design. Retry a `retryable: true` failure once with a new `requestId` before giving up.
- Save or export only when requested and only to a path accepted by Electron's configured roots. Do not overwrite an important existing file without explicit direction.
- A path the editor may not reach raises a permission request in the editor window rather than an immediate failure: the user is shown what was asked for and picks the folder in their system's file dialog. Wait for that. If they decline, the call fails with `path_consent_denied` — a decision, not a fault. Report it as one, name the folder that was refused, and do not retry it, do not copy media somewhere else to get past it, and do not ask again for the same folder in the same session. `get_diagnostics` and `health_check` both report `roots`, `rootSource` and a readable `rootNotice`, so read those before describing what the editor can and cannot see. `SVE_MCP_ROOTS` is an advanced override, not the usual way in; the usual way is the user allowing a folder, which they can also do from Allowed folders in the editor's project settings.
- Treat `editor_reconnecting` and other errors carrying `recoverable: true` as transient. Wait for `retryAfterMs`, call `health_check`, and retry with the same `requestId`.
- Every project mutation (`add_media`, `queue_media_import`, `open_project`, `set_project_soundtrack`, `analyze_silence`, `analyze_noise`, `suppress_noise`, a committed `apply_edit_batch`, `undo`, or `redo`) needs one non-empty unique `requestId`. Preserve that exact id and exact payload while its outcome is uncertain, including after a recoverable disconnect. The editor replays the first result instead of applying it twice. Never reuse an id for different content. After Electron restarts, read the restored project and generate fresh ids against its new revision.
- The editor automatically writes `simplevlogeditor-recovery.sve.json` in the active project root after MCP mutations, media commits, and manual user edits. Use `checkpoint_project` before a risky handoff, `get_recovery_state` to verify it, `restart_editor` to recover a broken editor, and `close_editor` only when the task or user requires the app to close.

## Always deliver the shot list and the description

Two things are part of every finished edit, whether or not the user asks for
them. Report both in chat when you finish, alongside what changed.

**A shot list of the pictures.** Every image you placed, each with the container
it sits in, its start and duration on that container's own source clock, the
same times as output timecodes from `get_timeline`, and one line saying what the
picture shows and why it is there. Say plainly which images in the working
directory you left out and why. If you placed none, say so and say why — an
empty shot list is an answer, an absent one is an omission.

**A description of the video.** A title line and a short paragraph of what the
finished video is about, drawn from the transcript and the frames rather than
from the file names, followed by the moments worth marking as chapters with
their output timecodes. It is for the user to paste where the video will be
published.

**The description is written in the language of the prompt.** The brief the user
wrote is what decides it — a Portuguese brief gets a Portuguese description,
whatever language the speech or the file names are in. If you cannot write well
in that language, use English and say that is what you did. This applies to the
description and the chapter titles only: interface strings, log lines and your
own account of what you changed stay in English.

The editor's MCP activity console is visible to the user and remains minimized if the user minimizes it. Keep tool calls meaningfully grouped. At the end, save a checkpoint, call `finish_editing` with a concise summary, and let the on-screen modal ask whether to watch the preview or render immediately. Also report subjective decisions, current project revision, and saved/exported paths in chat.

For the complete command and operation catalogue, read [MCP operations](references/mcp-operations.md) when planning a concrete edit.
